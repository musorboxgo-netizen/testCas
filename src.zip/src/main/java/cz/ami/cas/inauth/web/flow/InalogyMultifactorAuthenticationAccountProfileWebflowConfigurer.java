package cz.ami.cas.inauth.web.flow;

import lombok.val;
import org.apereo.cas.configuration.CasConfigurationProperties;
import org.apereo.cas.web.flow.CasWebflowConfigurer;
import org.apereo.cas.web.flow.CasWebflowConstants;
import org.apereo.cas.web.flow.actions.PopulateMessageContextAction;
import org.apereo.cas.web.flow.configurer.MultifactorAuthenticationAccountProfileWebflowConfigurer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.webflow.definition.registry.FlowDefinitionRegistry;
import org.springframework.webflow.engine.ViewState;
import org.springframework.webflow.engine.builder.support.FlowBuilderServices;

/**
 * This is {@link InalogyMultifactorAuthenticationAccountProfileWebflowConfigurer}.
 *
 * @author Misagh Moayyed
 * @since 7.0.0
 */
public class InalogyMultifactorAuthenticationAccountProfileWebflowConfigurer extends MultifactorAuthenticationAccountProfileWebflowConfigurer {
    public InalogyMultifactorAuthenticationAccountProfileWebflowConfigurer(final FlowBuilderServices flowBuilderServices,
                                                                           final FlowDefinitionRegistry accountProfileFlowRegistry,
                                                                           final ConfigurableApplicationContext applicationContext,
                                                                           final CasConfigurationProperties casProperties) {
        super(flowBuilderServices, accountProfileFlowRegistry, applicationContext, casProperties);
    }

    @Override
    protected void doInitialize() {
        super.doInitialize();
        val accountFlow = getFlow(CasWebflowConfigurer.FLOW_ID_ACCOUNT);

        val myAccountView = getState(accountFlow, CasWebflowConstants.STATE_ID_MY_ACCOUNT_PROFILE_VIEW, ViewState.class);
        myAccountView.getRenderActionList().add(createEvaluateAction(InalogyWebflowConstants.ACTION_ID_ACCOUNT_PROFILE_INALOGY_MFA_PREPARE));

        val regViewState = createViewState(accountFlow, CasWebflowConstants.STATE_ID_VIEW_REGISTRATION, "inauth/casInalogyAuthenticatorRegistrationView");
        regViewState.getEntryActionList().add(createEvaluateAction(InalogyWebflowConstants.ACTION_ID_ACCOUNT_PROFILE_INALOGY_MFA_REGISTRATION));
        regViewState.getEntryActionList().addAll(createEvaluateAction(InalogyWebflowConstants.ACTION_ID_INALOGY_ACCOUNT_CREATE_REGISTRATION));
        createTransitionForState(regViewState, CasWebflowConstants.TRANSITION_ID_SUBMIT, InalogyWebflowConstants.STATE_ID_INALOGY_SAVE_REGISTRATION);

        val acctRegSaveState = createActionState(accountFlow, InalogyWebflowConstants.STATE_ID_INALOGY_SAVE_REGISTRATION,
            createEvaluateAction(InalogyWebflowConstants.ACTION_ID_INALOGY_SAVE_ACCOUNT_REGISTRATION));
        createTransitionForState(acctRegSaveState, CasWebflowConstants.TRANSITION_ID_SUCCESS, InalogyWebflowConstants.STATE_ID_MY_ACCOUNT_PROFILE_INALOGY_REGISTRATION_FINALIZED);
        createStateDefaultTransition(acctRegSaveState, CasWebflowConstants.STATE_ID_VIEW_REGISTRATION);
        val finalizeRegistrationAction = new PopulateMessageContextAction.Info("screen.account.mfadevices.register.success")
            .setEventId(CasWebflowConstants.TRANSITION_ID_SUCCESS);
        val acctRegFinalize = createActionState(accountFlow, InalogyWebflowConstants.STATE_ID_MY_ACCOUNT_PROFILE_INALOGY_REGISTRATION_FINALIZED, finalizeRegistrationAction);
        createStateDefaultTransition(acctRegFinalize, CasWebflowConstants.STATE_ID_MY_ACCOUNT_PROFILE_VIEW);

        val accountProfileView = (ViewState) accountFlow.getState(CasWebflowConstants.STATE_ID_MY_ACCOUNT_PROFILE_VIEW);
        createTransitionForState(accountProfileView, "registerInalogy", regViewState.getId());
    }
}
