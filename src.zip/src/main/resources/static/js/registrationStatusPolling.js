(function() {
    function getPushRegRequestId() {
        const el = document.querySelector('input[name="regRequestId"]');
        return el ? el.value : null;
    }

    function pollRegStatus() {
        const requestId = getPushRegRequestId();
        if (!requestId) {
            setTimeout(pollRegStatus, 2200);
            return;
        }
        fetch('/cas/inalogy/check/registration?requestId=' + encodeURIComponent(requestId), {cache: 'no-store'})
            .then(r => r.json())
            .then(data => {
                if (data.status === 'REGISTERED') {
                    document.getElementById('registration-form').submit();
                } else if (data.status === 'REJECTED') {
                    window.location.href = '/cas/login';
                } else if (data.status === 'EXPIRED') {
                    window.location.href = '/cas/login';
                } else {
                    setTimeout(pollRegStatus, 2200);
                }
            })
            .catch(() => setTimeout(pollRegStatus, 2200));
    }

    document.addEventListener('DOMContentLoaded', function() {
        const TIMEOUT_MS = 45000; // 1 минута
        setTimeout(() => {
            window.location.href = '/cas/login';
        }, TIMEOUT_MS);

        pollRegStatus();
    });
})();